package com.app.quickfunds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickfundsApplicationTests {

	@Test
	void contextLoads() {
	}

}
