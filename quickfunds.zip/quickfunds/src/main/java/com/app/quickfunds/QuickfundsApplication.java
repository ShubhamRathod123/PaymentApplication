package com.app.quickfunds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuickfundsApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuickfundsApplication.class, args);
	}

}
